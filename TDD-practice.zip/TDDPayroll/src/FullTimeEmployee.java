
public class FullTimeEmployee extends Employee {
	private int salary;
	
	public FullTimeEmployee(String name, int salary) throws Exception {
		super(name);
		
		if (salary <= 0 ) {
			throw new Exception("Bad value:" + salary);
		}
		
		this.salary = salary;
		// TODO Auto-generated constructor stub
	}
	
	public int calcMonthlyPay() {
		// TODO Auto-generated method stub
		return this.salary;
	}
	
}
