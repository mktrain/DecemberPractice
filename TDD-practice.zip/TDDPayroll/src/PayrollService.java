import java.util.Iterator;
import java.util.List;

public class PayrollService {

	public static int calcMonthlyTotal(List<Employee> employees) {
		// TODO Auto-generated method stub
		int total = 0;
		
		for (Employee employee : employees) {
			total += employee.calcMonthlyPay();
		}
		
		
		return total;
	}

	public static int calcYearlyTotal(List<Employee> employees) {
		// TODO Auto-generated method stub
		return 0;
	}

}
