import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestPayrollService {
	
	List<Employee> employees ;

	@BeforeClass
	public static void init() {
		//create a DB connection
	}
	
	@Before
	public void setup() throws Exception {
		employees = new ArrayList();
		
		employees.add(new FullTimeEmployee("Adam", 10000));
						//	  new FullTimeEmployee("Bob", 5000),
						 //     new FullTimeEmployee("Casey", 1000)
			//	);
	}
	
	@After
	public void cleanUpBetweenTests() {
		//clean up between tests
	}
	
	@AfterClass
	public static void cleanUpAfterTests() {
		
	}
	
//	@Test
//	public void testPayrollService() {
//		List<Employee> employees = 
//				Arrays.asList(new Employee("Adam", 10000),
//							  new Employee("Bob", 5000),
//						      new Employee("Casey", 1000)
//				);
//		
//		int total = PayrollService.calcMonthlyTotal(employees);
//		
//		assertEquals(16000,total);
//	}
	
//	@Test
//	public void testPayrollServiceFullTimeMonthly() throws Exception {
//		
//		int total = PayrollService.calcMonthlyTotal(employees);
//		
//		assertEquals(16000,total);
//	}
	
	
//	@Test
//	public void testPayrollServiceFullTimeDaily() throws Exception {
//		
//	//	double total = PayrollService.calcDailyTotal(employees);
//		//MUST USE 3rd paramater for tolerance with doubles
//		//assertEquals(16000.0,total,0.0);
//	}
	
//	@Test
//	public void testPayrollServiceFullTimeYearly() throws Exception {
//		
//		
//		int total = PayrollService.calcYearlyTotal(employees);
//		
//		assertEquals(10,total);
//	}

	@Test
	public void testPayrollServiceBadValues() throws Exception {
			
			employees.add(new FullTimeEmployee("abc",122));
			
			int total = PayrollService.calcYearlyTotal(employees);
			
			assertEquals(10, total);
		
	}
	
	
	
}
